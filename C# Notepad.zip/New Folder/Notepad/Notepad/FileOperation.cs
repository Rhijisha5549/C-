﻿using System;

namespace Notepad
{
    internal class FileOperation
    {
        public string Filename { get; internal set; }
        public bool IsFileSaved { get; internal set; }

        internal void InitializeNewFile()
        {
            throw new NotImplementedException();
        }

        internal void SaveFile(string fileName, object lines)
        {
            throw new NotImplementedException();
        }

        internal void SaveFile(string filename, object lines)
        {
            throw new NotImplementedException();
        }
    }
}