﻿using System;

namespace EditOperation
{
    public class Class1
    {
    }
}
