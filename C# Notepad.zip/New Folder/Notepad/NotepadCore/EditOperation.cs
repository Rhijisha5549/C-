﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotepadCore
{
   public class EditOperation
    {
        public string DateTime_Now()
        {
            return DateTime.Now.ToString();
        }
    }
}
